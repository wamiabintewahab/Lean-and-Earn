# Learn and Earn AI — Version 0.3 prototype

A beginner-friendly, browser-only coding playground prototype.

## Open it locally
1. Download and extract the ZIP.
2. Open `learn-and-earn-ai-v3/index.html` in a modern browser.
3. Select an example, press **Run code**, or edit the code.
4. Use **Reset example** to restore the default example.

## What is included
- Responsive landing page and navigation
- Coding playground with a small, deliberately limited interpreter
- `let`, `print(...)`, quoted strings, numbers, `+`, and `//` comments
- Basic beginner-oriented error messages
- Three clickable example lessons
- Keyboard focus styling, skip link, live output announcement, and reduced-motion support
- No accounts, server, analytics, or network calls

## Important limitations
This is a prototype, not a production-ready service or a full programming language. It does not include AI, cloud saving, sign-in, a backend, payments, or eye-tracking. The demo interpreter is intentionally limited and should not be used to execute untrusted general-purpose code. Before public launch, test across browsers and devices, review accessibility, and conduct a security/privacy review appropriate to any new backend features.

## Publish with GitHub Pages (when ready)
1. Create a GitHub repository.
2. Upload the contents of this folder (so `index.html` is at the repository root).
3. In the repository, open **Settings → Pages**.
4. Choose deployment from the `main` branch and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site and test the public URL.

GitHub Pages publishes static files; it does not provide user accounts or cloud storage by itself.
